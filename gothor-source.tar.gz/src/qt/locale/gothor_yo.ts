<TS language="yo" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>&amp;New</source>
        <translation>&amp;ati tuntun</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>GothorGUI</name>
    <message>
        <source>Open Wallet</source>
        <translation>sii apamowo</translation>
    </message>
    <message>
        <source>Open a wallet</source>
        <translation>sii apamowo</translation>
    </message>
    <message>
        <source>Close Wallet...</source>
        <translation>ti apamowo</translation>
    </message>
    <message>
        <source>Close wallet</source>
        <translation>Ti Apamowo</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Date</source>
        <translation>Ojo</translation>
    </message>
    </context>
<context>
    <name>CreateWalletActivity</name>
    </context>
<context>
    <name>CreateWalletDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>name</source>
        <translation>oruko</translation>
    </message>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Ka bo</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OpenWalletActivity</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;o da</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>fi aworan &amp;pamo</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Name</source>
        <translation>Oruko</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>okan ati &amp;odun</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>fi aworan &amp;pamo</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Ojo</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Date</source>
        <translation>Ojo</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>wo nikan</translation>
    </message>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Ojo</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>wo nikan</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>This year</source>
        <translation>Odun yi</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Ojo</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletController</name>
    <message>
        <source>Close wallet</source>
        <translation>Ti Apamowo</translation>
    </message>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>gothor-core</name>
    </context>
</TS>